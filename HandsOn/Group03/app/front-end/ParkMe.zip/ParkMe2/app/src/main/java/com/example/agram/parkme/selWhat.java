package com.example.agram.parkme;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.agram.parkme.model.Estacionamiento;
import com.example.agram.parkme.service.parkClient;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class selWhat extends AppCompatActivity {

    Button plazas,parquimetros,plazaParqui;
    public static String seleccion;
    public static List<String> dirParq = new LinkedList<>();

    String baseUrl="http://192.168.1.43:8888/parkMe/api/SparqlController/";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sel_what);
         
        final HashMap<String,String> busqueda= new HashMap<>();
        plazas = findViewById(R.id.plazasButton);
        parquimetros = findViewById(R.id.parquimetrosButton);
        plazaParqui = findViewById(R.id.plazasparquiButton);

        plazas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    seleccion="plazas";

                Intent i = new Intent(selWhat.this,zonasActivity.class);
                startActivity(i);
                }
        });


        parquimetros.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                busqueda.put("tipo",MainActivity.tipo);
                busqueda.put("direccion",MainActivity.direccion);
                busqueda.put("numero",MainActivity.numero);

                getDir(busqueda);


            }
        });

    }

    private void getDir(HashMap<String, String> busqueda) {

        //Crear la instancia Retrofit

        Retrofit.Builder builder = new Retrofit.Builder().baseUrl("" + baseUrl).addConverterFactory(GsonConverterFactory.create());
        Retrofit retrofit = builder.build();

        //Obtenemos el cliente y llamamos un request al objeto
        parkClient client = retrofit.create(parkClient.class);
        Call<List<String>> call = client.getParquimetro(busqueda);


        call.enqueue(new Callback<List<String>>() {
            @Override
            public void onResponse(Call<List<String>> call, Response<List<String>> response) {

                if (response.code() == 200) {

                    dirParq = response.body();
                    Toast.makeText(selWhat.this, "Datos obtenidos correctamente", Toast.LENGTH_LONG).show();
                    Intent i = new Intent(selWhat.this,MapsActivityParquimetro.class);
                    startActivity(i);

                } else if (response.code() == 400) {
                    Toast.makeText(selWhat.this, "WTF", Toast.LENGTH_LONG).show();
                }

            }

            @Override
            public void onFailure(Call<List<String>> call, Throwable t) {

                Toast.makeText(selWhat.this, "No hay conexión", Toast.LENGTH_LONG).show();

            }
        });

    }


}
