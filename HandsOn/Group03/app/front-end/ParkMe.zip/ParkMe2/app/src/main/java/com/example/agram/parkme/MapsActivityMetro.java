package com.example.agram.parkme;

import android.content.Context;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;

import com.example.agram.parkme.model.Estacionamiento;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;


public class MapsActivityMetro extends FragmentActivity implements
        OnMapReadyCallback, GoogleMap.OnMapClickListener {

    final LatLng start = new LatLng(40.416770, -3.703768);
    LatLng objetivo = new LatLng(0, 0);
    LatLng Marker2 = new LatLng(0, 0);
    int i = 1;
    private GoogleMap mapa;



    LatLng dir;
    List<LatLng> dirEst = new LinkedList<>();

    String direccion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        SupportMapFragment mapFragment = (SupportMapFragment)
                getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);


        List<Estacionamiento> estacionamiento= MainActivity.estacionamientos;

       dir = getLocationFromAddress(this,MainActivity.direccion+", Madrid");

       for(int i=0;i<estacionamiento.size();i++){
           LatLng result = getLocationFromAddress(this,estacionamiento.get(i).getDireccion()+", Madrid");
           dirEst.add(result);

       }

    }


    @Override
    public void onMapReady(GoogleMap googleMap) {

        mapa = googleMap;
        mapa.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        direccion = MainActivity.direccion;
        mapa.moveCamera(CameraUpdateFactory.newLatLngZoom(start, 15));
        mapa.setOnMapClickListener(this);
        mapa.getUiSettings().setMapToolbarEnabled(false);

        mapa.moveCamera(CameraUpdateFactory.newLatLngZoom(dir, 15));

        Marker mrk = mapa.addMarker(new MarkerOptions().position(dir)
                .icon(BitmapDescriptorFactory
                        .defaultMarker(BitmapDescriptorFactory.HUE_YELLOW)));

        for(int i=0;i<dirEst.size();i++){

            Marker marker = mapa.addMarker(new MarkerOptions().position(dirEst.get(i))
                    .icon(BitmapDescriptorFactory
                            .defaultMarker(BitmapDescriptorFactory.HUE_RED)));
            marker.setTitle("Diección "+MainActivity.estacionamientos.get(i).getDireccion());
            marker.setSnippet(MainActivity.estacionamientos.get(i).getPlazas()+" plazas de zona "+MainActivity.estacionamientos.get(i).getTipo());
        }



        }

    @Override
    public void onMapClick(LatLng latLng) {

    }

    public LatLng getLocationFromAddress(Context context, String strAddress) {

        Geocoder coder = new Geocoder(context);
        List<Address> address;
        LatLng p1 = null;

        try {
            // May throw an IOException
            address = coder.getFromLocationName(strAddress, 5);
            if (address == null) {
                return null;
            }
            Address location = address.get(0);
            location.getLatitude();
            location.getLongitude();

            p1 = new LatLng(location.getLatitude(), location.getLongitude() );

        } catch (IOException ex) {

            ex.printStackTrace();
        }

        return p1;
    }
}




