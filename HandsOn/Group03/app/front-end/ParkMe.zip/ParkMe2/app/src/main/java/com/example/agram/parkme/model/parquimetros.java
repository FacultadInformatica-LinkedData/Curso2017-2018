package com.example.agram.parkme.model;

/**
 * Created by agram on 15/12/2017.
 */

public class parquimetros {




}
