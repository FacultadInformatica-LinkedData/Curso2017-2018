package com.example.agram.parkme;

import android.Manifest;
import android.animation.TypeEvaluator;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.icu.text.DecimalFormat;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.CountDownTimer;
import android.os.Vibrator;
import android.provider.Settings;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.agram.parkme.model.MyItem;
import com.example.agram.parkme.service.parkClient;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.maps.android.clustering.ClusterManager;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MapsActivityParquimetro extends FragmentActivity implements
        OnMapReadyCallback, GoogleMap.OnMapClickListener {

    final LatLng start = new LatLng(40.416770, -3.703768);
    LatLng objetivo = new LatLng(0, 0);
    LatLng Marker2 = new LatLng(0, 0);
    int i = 1;
    private GoogleMap mapa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        SupportMapFragment mapFragment = (SupportMapFragment)
                getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);


    }




    @SuppressLint("MissingPermission")
    @Override
    public void onMapReady(GoogleMap googleMap) {

        mapa = googleMap;
        mapa.setMapType(GoogleMap.MAP_TYPE_NORMAL);

        mapa.setBuildingsEnabled(true);

        mapa.moveCamera(CameraUpdateFactory.newLatLngZoom(start, 15));

        mapa.setOnMapClickListener(this);
        mapa.getUiSettings().setMapToolbarEnabled(false);

        //MONCLOA
        LatLng MA= new LatLng(40.441244, -3.752692);
        Marker MoncloaAravaca = mapa.addMarker(new MarkerOptions().position(MA)
                .icon(BitmapDescriptorFactory
                        .defaultMarker(BitmapDescriptorFactory.HUE_YELLOW)));
        MoncloaAravaca.setTitle("Distrito Moncloa-Aravaca");
        MoncloaAravaca.setSnippet("Número de Parquímetros: "+MainActivity.distritParq.get("Moncloa-aravaca"));


        //TETUAN
        LatLng TE= new LatLng(40.458526, -3.698320);
        Marker tetuan = mapa.addMarker(new MarkerOptions().position(TE)
                .icon(BitmapDescriptorFactory
                        .defaultMarker(BitmapDescriptorFactory.HUE_AZURE)));
        tetuan.setTitle("Distrito Tetuán");
        tetuan.setSnippet("Número de Parquímetros: "+MainActivity.distritParq.get("Tetuán"));


        //Arganzuela
        LatLng AR= new LatLng(40.399006, -3.698492);
        Marker arganzuela = mapa.addMarker(new MarkerOptions().position(AR)
                .icon(BitmapDescriptorFactory
                        .defaultMarker(BitmapDescriptorFactory.HUE_CYAN)));
        arganzuela.setTitle("Distrito Arganzuela");
        arganzuela.setSnippet("Número de Parquímetros: "+MainActivity.distritParq.get("Arganzuela"));




        //Centro
        LatLng CT= new LatLng(40.411554, -3.705296);
        Marker centro = mapa.addMarker(new MarkerOptions().position(CT)
                .icon(BitmapDescriptorFactory
                        .defaultMarker(BitmapDescriptorFactory.HUE_ORANGE)));
        centro.setTitle("Distrito Centro");
        centro.setSnippet("Número de Parquímetros:  "+MainActivity.distritParq.get("Centro"));




        //Fuencaral-El Pardo
        LatLng FP= new LatLng(40.533686, -3.784421);
        Marker fpardo = mapa.addMarker(new MarkerOptions().position(FP)
                .icon(BitmapDescriptorFactory
                        .defaultMarker(BitmapDescriptorFactory.HUE_ORANGE)));
        fpardo.setTitle("Distrito Fuencaral-El Pardo");
        fpardo.setSnippet("Número de Parquímetros: "+MainActivity.distritParq.get("Tetuán"));


        //Salamanca
        LatLng SL= new LatLng(40.430264, -3.675151);
        Marker salamanca = mapa.addMarker(new MarkerOptions().position(SL)
                .icon(BitmapDescriptorFactory
                        .defaultMarker(BitmapDescriptorFactory.HUE_VIOLET)));
        salamanca.setTitle("Distrito Salamanca");
        salamanca.setSnippet("Número de Parquímetros: "+MainActivity.distritParq.get("Salamanca"));



        //Chamberí
        LatLng CH= new LatLng(40.438028, -3.701691);
        Marker chamberi = mapa.addMarker(new MarkerOptions().position(CH)
                .icon(BitmapDescriptorFactory
                        .defaultMarker(BitmapDescriptorFactory.HUE_YELLOW)));
        chamberi.setTitle("Distrito Chamberí");
        chamberi.setSnippet("Número de Parquímetros: "+MainActivity.distritParq.get("Chamberí"));



//        //Retiro
//        LatLng CT= new LatLng(40.411170, -3.675153);
//        Marker centro = mapa.addMarker(new MarkerOptions().position(CT)
//                .icon(BitmapDescriptorFactory
//                        .defaultMarker(136.6f)));
//        centro.setTitle("Distrito Retiro");
//        centro.setSnippet("Número de Parquímetros: "+distritParq.get("Retiro"));





        //Chamartín
        LatLng CM= new LatLng(40.464253, -3.6722753);
        Marker chamartin = mapa.addMarker(new MarkerOptions().position(CM)
                .icon(BitmapDescriptorFactory
                        .defaultMarker(6.6f)));
        chamartin.setTitle("Distrito Chamartín");
        chamartin.setSnippet("Número de Parquímetros:  "+MainActivity.distritParq.get("Chamartín"));




    }

    @Override public void onMapClick(LatLng puntoPulsado) {

//        mapa.clear();
//        Marker mark = mapa.addMarker(new MarkerOptions().position(puntoPulsado)
//                .icon(BitmapDescriptorFactory
//                        .defaultMarker(BitmapDescriptorFactory.HUE_YELLOW)));
//
//        final LatLng Marcador1 = new LatLng( puntoPulsado.latitude , puntoPulsado.longitude);
//        Marker2=Marcador1;


    }

}




