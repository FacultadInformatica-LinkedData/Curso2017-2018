package com.example.agram.parkme.service;

import com.example.agram.parkme.model.Estacionamiento;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.QueryMap;

/**
 * Created by agram on 15/12/2017.
 */

public interface parkClient {

    @GET("numeroDePlazasPorDistrito")
    Call<HashMap<String,Integer>> numPark ();

    @GET("numeroDeParquimetrosPorDistrito")
    Call<HashMap<String,Integer>> numParq ();

    @GET("direccionDeEstacionamiento")
    Call<List<Estacionamiento>> getEstacionamiento(@QueryMap() Map<String, String> plazas);

    @GET("direccionDeParquimetro")
    Call<List<String>> getParquimetro(@QueryMap() Map<String, String> plazas);

    @GET("estacionamientoDeMetro")
    Call<List<Estacionamiento>> getMetro(@QueryMap() Map<String, String> plazas);



}
