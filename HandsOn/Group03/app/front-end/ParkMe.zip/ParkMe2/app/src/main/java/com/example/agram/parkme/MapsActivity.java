package com.example.agram.parkme;

import android.Manifest;
import android.animation.TypeEvaluator;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.icu.text.DecimalFormat;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.CountDownTimer;
import android.os.Vibrator;
import android.provider.Settings;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.agram.parkme.model.MyItem;
import com.example.agram.parkme.service.parkClient;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.maps.android.clustering.ClusterManager;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MapsActivity extends FragmentActivity implements
        OnMapReadyCallback, GoogleMap.OnMapClickListener {

    final LatLng start = new LatLng(40.416770, -3.703768);
    LatLng objetivo = new LatLng(0, 0);
    LatLng Marker2 = new LatLng(0, 0);
    int i = 1;
    private GoogleMap mapa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        SupportMapFragment mapFragment = (SupportMapFragment)
                getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);


    }




    @SuppressLint("MissingPermission")
    @Override
    public void onMapReady(GoogleMap googleMap) {

        mapa = googleMap;
        mapa.setMapType(GoogleMap.MAP_TYPE_NORMAL);

        mapa.setBuildingsEnabled(true);

        mapa.moveCamera(CameraUpdateFactory.newLatLngZoom(start, 15));

        mapa.setOnMapClickListener(this);
        mapa.getUiSettings().setMapToolbarEnabled(false);

        //MONCLOA
        LatLng MA= new LatLng(40.441244, -3.752692);
        Marker MoncloaAravaca = mapa.addMarker(new MarkerOptions().position(MA)
                .icon(BitmapDescriptorFactory
                       .defaultMarker(BitmapDescriptorFactory.HUE_YELLOW)));
        MoncloaAravaca.setTitle("Distrito Moncloa-Aravaca");
        MoncloaAravaca.setSnippet("Número de Aparcamientos: "+MainActivity.distritPark.get("Moncloa-aravaca"));


        //TETUAN
        LatLng TE= new LatLng(40.458526, -3.698320);
        Marker tetuan = mapa.addMarker(new MarkerOptions().position(TE)
                .icon(BitmapDescriptorFactory
                        .defaultMarker(BitmapDescriptorFactory.HUE_AZURE)));
        tetuan.setTitle("Distrito Tetuán");
        tetuan.setSnippet("Número de Aparcamientos: "+MainActivity.distritPark.get("Tetuán"));

        //Valverde
        LatLng VA= new LatLng(40.496225, -3.695550);
        Marker valverde = mapa.addMarker(new MarkerOptions().position(VA)
                .icon(BitmapDescriptorFactory
                        .defaultMarker(BitmapDescriptorFactory.HUE_BLUE)));
        valverde.setTitle("Distrito Valverde");
        valverde.setSnippet("Número de Aparcamientos: "+MainActivity.distritPark.get("Tetuán"));


        //Arganzuela
        LatLng AR= new LatLng(40.399006, -3.698492);
        Marker arganzuela = mapa.addMarker(new MarkerOptions().position(AR)
                .icon(BitmapDescriptorFactory
                        .defaultMarker(BitmapDescriptorFactory.HUE_CYAN)));
        arganzuela.setTitle("Distrito Arganzuela");
        arganzuela.setSnippet("Número de Aparcamientos: "+MainActivity.distritPark.get("Arganzuela"));


        //Vicálvaro
        LatLng VC= new LatLng(40.400380, -3.602591);
        Marker vicalvaro = mapa.addMarker(new MarkerOptions().position(VC)
                .icon(BitmapDescriptorFactory
                        .defaultMarker(BitmapDescriptorFactory.HUE_CYAN)));
        vicalvaro.setTitle("Distrito Vicálvaro");
        vicalvaro.setSnippet("Número de Aparcamientos: "+MainActivity.distritPark.get("Vicálvaro"));


        //Carabanchel
        LatLng CA= new LatLng(40.377742, -3.7531162);
        Marker carabanchel = mapa.addMarker(new MarkerOptions().position(CA)
                .icon(BitmapDescriptorFactory
                        .defaultMarker(BitmapDescriptorFactory.HUE_GREEN)));
        carabanchel.setTitle("Distrito Carabanchel");
        carabanchel.setSnippet("Número de Aparcamientos: "+MainActivity.distritPark.get("Carabanchel"));



        //Barajas
        LatLng BA= new LatLng(40.465655, -3.593185);
        Marker barajas = mapa.addMarker(new MarkerOptions().position(BA)
                .icon(BitmapDescriptorFactory
                        .defaultMarker(BitmapDescriptorFactory.HUE_MAGENTA)));
        barajas.setTitle("Distrito Barajas");
        barajas.setSnippet("Número de Aparcamientos: "+MainActivity.distritPark.get("Barajas"));


        //SanBlas
        LatLng SB= new LatLng(40.431904, -3.626249);
        Marker sanblas = mapa.addMarker(new MarkerOptions().position(SB)
                .icon(BitmapDescriptorFactory
                        .defaultMarker(BitmapDescriptorFactory.HUE_ORANGE)));
        sanblas.setTitle("Distrito SanBlas");
        sanblas.setSnippet("Número de Aparcamientos:  "+MainActivity.distritPark.get("San Blas"));


        //Centro
        LatLng CT= new LatLng(40.411554, -3.705296);
        Marker centro = mapa.addMarker(new MarkerOptions().position(CT)
                .icon(BitmapDescriptorFactory
                        .defaultMarker(BitmapDescriptorFactory.HUE_ORANGE)));
        centro.setTitle("Distrito Centro");
        centro.setSnippet("Número de Aparcamientos:  "+MainActivity.distritPark.get("Centro"));


        //Ciudad Lineal
        LatLng CL= new LatLng(40.441343, -3.652198);
        Marker clineal = mapa.addMarker(new MarkerOptions().position(CL)
                .icon(BitmapDescriptorFactory
                        .defaultMarker(BitmapDescriptorFactory.HUE_RED)));
        clineal.setTitle("Distrito Ciudad Lineal");
        clineal.setSnippet("Número de Aparcamientos: "+MainActivity.distritPark.get("Ciudad Lineal"));



        //Fuencaral-El Pardo
        LatLng FP= new LatLng(40.533686, -3.784421);
        Marker fpardo = mapa.addMarker(new MarkerOptions().position(FP)
                .icon(BitmapDescriptorFactory
                        .defaultMarker(BitmapDescriptorFactory.HUE_ORANGE)));
        fpardo.setTitle("Distrito Fuencaral-El Pardo");
        fpardo.setSnippet("Número de Aparcamientos: "+MainActivity.distritPark.get("Tetuán"));



        //Latina
        LatLng LT= new LatLng(40.402814, -3.744776);
        Marker latina = mapa.addMarker(new MarkerOptions().position(LT)
                .icon(BitmapDescriptorFactory
                        .defaultMarker(BitmapDescriptorFactory.HUE_ROSE)));
        latina.setTitle("Distrito Latina");
        latina.setSnippet("Número de Aparcamientos: "+MainActivity.distritPark.get("Tetuán"));



        //Salamanca
        LatLng SL= new LatLng(40.430264, -3.675151);
        Marker salamanca = mapa.addMarker(new MarkerOptions().position(SL)
                .icon(BitmapDescriptorFactory
                        .defaultMarker(BitmapDescriptorFactory.HUE_VIOLET)));
        salamanca.setTitle("Distrito Salamanca");
        salamanca.setSnippet("Número de Aparcamientos: "+MainActivity.distritPark.get("Salamanca"));



        //Chamberí
        LatLng CH= new LatLng(40.438028, -3.701691);
        Marker chamberi = mapa.addMarker(new MarkerOptions().position(CH)
                .icon(BitmapDescriptorFactory
                        .defaultMarker(BitmapDescriptorFactory.HUE_YELLOW)));
        chamberi.setTitle("Distrito Chamberí");
        chamberi.setSnippet("Número de Aparcamientos: "+MainActivity.distritPark.get("Chamberí"));



//        //Retiro
//        LatLng CT= new LatLng(40.411170, -3.675153);
//        Marker centro = mapa.addMarker(new MarkerOptions().position(CT)
//                .icon(BitmapDescriptorFactory
//                        .defaultMarker(136.6f)));
//        centro.setTitle("Distrito Retiro");
//        centro.setSnippet("Número de Aparcamientos: "+distritPark.get("Retiro"));



        //Villaverde
        LatLng VV= new LatLng(40.346710, -3.7015713);
        Marker villaverde = mapa.addMarker(new MarkerOptions().position(VV)
                .icon(BitmapDescriptorFactory
                        .defaultMarker(106.6f)));
        villaverde.setTitle("Distrito Villaverde");
        villaverde.setSnippet("Número de Aparcamientos: "+MainActivity.distritPark.get("Villaverde"));



        //Chamartín
        LatLng CM= new LatLng(40.464253, -3.6722753);
        Marker chamartin = mapa.addMarker(new MarkerOptions().position(CM)
                .icon(BitmapDescriptorFactory
                        .defaultMarker(6.6f)));
        chamartin.setTitle("Distrito Chamartín");
        chamartin.setSnippet("Número de Aparcamientos:  "+MainActivity.distritPark.get("Chamartín"));


        //Moratalaz
        LatLng MZ= new LatLng(40.408062, -3.644502);
        Marker moratalaz = mapa.addMarker(new MarkerOptions().position(MZ)
                .icon(BitmapDescriptorFactory
                        .defaultMarker(52.6f)));
        moratalaz.setTitle("Distrito Moratalaz");
        moratalaz.setSnippet("Número de Aparcamientos: "+MainActivity.distritPark.get("Moratalaz"));



        //Villa de Vallecas
        LatLng VLL= new LatLng(40.408062, -3.644502);
        Marker vvallecas = mapa.addMarker(new MarkerOptions().position(VLL)
                .icon(BitmapDescriptorFactory
                        .defaultMarker(89.6f)));
        vvallecas.setTitle("Distrito Villa de Vallecas");
        vvallecas.setSnippet("Número de Aparcamientos: "+MainActivity.distritPark.get("Villa De Vallecas"));


        //Usera
        LatLng US= new LatLng(40.378138, -3.703871);
        Marker usera = mapa.addMarker(new MarkerOptions().position(US)
                .icon(BitmapDescriptorFactory
                        .defaultMarker(175.6f)));
        usera.setTitle("Distrito Usera");
        usera.setSnippet("Número de Aparcamientos: "+MainActivity.distritPark.get("Usera"));


        //Puente de Vallecas
        LatLng PV= new LatLng(40.378138, -3.703871);
        Marker pvallecas = mapa.addMarker(new MarkerOptions().position(PV)
                .icon(BitmapDescriptorFactory
                        .defaultMarker(256.6f)));
        pvallecas.setTitle("Distrito Puente de Vallecas");
        pvallecas.setSnippet("Número de Aparcamientos: "+MainActivity.distritPark.get("Puente De Vallecas"));


        //Hortaleza
        LatLng HZ= new LatLng(40.468438, -3.645610);
        Marker hortaleza = mapa.addMarker(new MarkerOptions().position(HZ)
                .icon(BitmapDescriptorFactory
                        .defaultMarker(200.6f)));
        hortaleza.setTitle("Distrito Puente de Vallecas");
        hortaleza.setSnippet("Número de Aparcamientos:  "+MainActivity.distritPark.get("Hortaleza"));









    }

    @Override public void onMapClick(LatLng puntoPulsado) {

//        mapa.clear();
//        Marker mark = mapa.addMarker(new MarkerOptions().position(puntoPulsado)
//                .icon(BitmapDescriptorFactory
//                        .defaultMarker(BitmapDescriptorFactory.HUE_YELLOW)));
//
//        final LatLng Marcador1 = new LatLng( puntoPulsado.latitude , puntoPulsado.longitude);
//        Marker2=Marcador1;


    }

}




