package com.example.agram.parkme;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.agram.parkme.model.Estacionamiento;
import com.example.agram.parkme.service.parkClient;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class zonasActivity extends AppCompatActivity {

    Button azul,verde,recarga;
    public static String zona;
    public static List<Estacionamiento> estacionamientos = new LinkedList<>();


    String baseUrl="http://192.168.1.43:8888/parkMe/api/SparqlController/";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_zonas);
        final HashMap<String,String> busqueda= new HashMap<>();

        azul = findViewById(R.id.azulButton);
        verde = findViewById(R.id.verdeButton);


        azul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                zona="ZonaAzul";
                busqueda.put("tipo",MainActivity.tipo);
                busqueda.put("direccion",MainActivity.direccion);
                busqueda.put("numero",MainActivity.numero);
                busqueda.put("Zona",zona);
                getDir(busqueda);

            }
        });

    }

    private void getDir(HashMap<String, String> busqueda) {

        //Crear la instancia Retrofit

        Retrofit.Builder builder = new Retrofit.Builder().baseUrl("" + baseUrl).addConverterFactory(GsonConverterFactory.create());
        Retrofit retrofit = builder.build();

                //Obtenemos el cliente y llamamos un request al objeto
        parkClient client = retrofit.create(parkClient.class);
        Call<List<Estacionamiento>> call = client.getEstacionamiento(busqueda);


        call.enqueue(new Callback<List<Estacionamiento>>() {
            @Override
            public void onResponse(Call<List<Estacionamiento>> call, Response<List<Estacionamiento>> response) {

                if (response.code() == 200) {

                    estacionamientos = response.body();
                    Toast.makeText(zonasActivity.this, "Datos obtenidos correctamente", Toast.LENGTH_LONG).show();
                    Intent i = new Intent(zonasActivity.this,MapsActivityDirec.class);
                    startActivity(i);

                } else if (response.code() == 400) {
                    Toast.makeText(zonasActivity.this, "WTF", Toast.LENGTH_LONG).show();
                }

            }

            @Override
            public void onFailure(Call<List<Estacionamiento>> call, Throwable t) {

                Toast.makeText(zonasActivity.this, "No hay conexión", Toast.LENGTH_LONG).show();

            }
        });

    }


}
