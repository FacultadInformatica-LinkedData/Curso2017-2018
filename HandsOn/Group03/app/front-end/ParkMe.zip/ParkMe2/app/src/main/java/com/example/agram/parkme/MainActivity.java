package com.example.agram.parkme;

import android.app.AlertDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.example.agram.parkme.model.Estacionamiento;
import com.example.agram.parkme.service.parkClient;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    Button mapa,metro,interes,more;
    String baseUrl ="http://192.168.1.43:8888/parkMe/api/SparqlController/";
    public  static  HashMap<String, Integer>distritPark = new HashMap<>();
    public  static  HashMap<String, Integer>distritParq = new HashMap<>();
    public static String direccion,numero,tipo;

    final HashMap<String,String> busqueda= new HashMap<>();
    public static List<Estacionamiento> estacionamientos = new LinkedList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().requestFeature(Window.FEATURE_ACTION_BAR);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_main);

        mapa =findViewById(R.id.dButton);
        metro=findViewById(R.id.mButton);

        more=findViewById(R.id.moreButton);

        getPark();
        getParq();

        mapa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder mBuilder = new AlertDialog.Builder(MainActivity.this);
                final View mView = getLayoutInflater().inflate(R.layout.solicitudes_dialog, null);

                Button buscar = (Button)mView.findViewById(R.id.buscarButton);
                final EditText dir = (EditText)mView.findViewById(R.id.editTextDireccion2);
                final EditText num = (EditText)mView.findViewById(R.id.editTextDireccion);
                final EditText tipoE = (EditText)mView.findViewById(R.id.editTextDireccion3);
                buscar.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        direccion=dir.getText().toString();
                        numero = num.getText().toString();
                        tipo = tipoE.getText().toString();

                        Intent i = new Intent(MainActivity.this,selWhat.class);
                        startActivity(i);
                    }
                });

                mBuilder.setView(mView);
                AlertDialog dialog = mBuilder.create();
                dialog.show();

            }
        });

        metro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder mBuilder = new AlertDialog.Builder(MainActivity.this);
                final View mView = getLayoutInflater().inflate(R.layout.solicitudes_dialog_metro, null);

                final Button buscar = (Button)mView.findViewById(R.id.buscarButton);
                final EditText dir = (EditText)mView.findViewById(R.id.editTextDireccion2);

                buscar.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        direccion=dir.getText().toString();
                        busqueda.put("estacion","Estación de "+dir.getText().toString());
                        getMetroEst(busqueda);

                    }
                });

                mBuilder.setView(mView);
                AlertDialog dialog = mBuilder.create();
                dialog.show();
            }
        });

        more.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               // getPark();

                Intent i = new Intent(MainActivity.this,datosActivity.class);
                startActivity(i);

            }
        });

    }


    private void getParq() {

        Retrofit.Builder builder = new Retrofit.Builder().baseUrl("" + baseUrl).addConverterFactory(GsonConverterFactory.create());
        Retrofit retrofit = builder.build();

        Map<String, String> map = new HashMap<>();

        //Obtenemos el cliente y llamamos un request al objeto
        parkClient client = retrofit.create(parkClient.class);
        Call<HashMap<String, Integer>> call = client.numParq();

        call.enqueue(new Callback<HashMap<String, Integer>>() {
            @Override
            public void onResponse(Call<HashMap<String, Integer>> call, Response<HashMap<String, Integer>> response) {

                if (response.code() == 200) {

                    distritParq = response.body();
                    Toast.makeText(MainActivity.this, "Datos obtenidos correctamente", Toast.LENGTH_LONG).show();

                } else if (response.code() == 400) {
                    Toast.makeText(MainActivity.this, "WTF", Toast.LENGTH_LONG).show();
                }

            }

            @Override
            public void onFailure(Call<HashMap<String, Integer>> call, Throwable t) {

                Toast.makeText(MainActivity.this, "No hay conexión", Toast.LENGTH_LONG).show();

            }
        });
    }


    private void getPark() {

        Retrofit.Builder builder = new Retrofit.Builder().baseUrl(""+baseUrl).addConverterFactory(GsonConverterFactory.create());
        Retrofit retrofit = builder.build();

        Map<String,String> map = new HashMap<>();

        //Obtenemos el cliente y llamamos un request al objeto
        parkClient client = retrofit.create(parkClient.class);
        Call<HashMap<String,Integer>> call = client.numPark();

        call.enqueue(new Callback<HashMap<String,Integer>>() {
            @Override
            public void onResponse(Call<HashMap<String,Integer>> call, Response<HashMap<String,Integer>> response) {

                if(response.code()== 200) {

                    distritPark = response.body();
                    Toast.makeText(MainActivity.this, "Datos obtenidos correctamente", Toast.LENGTH_LONG).show();

                }else if (response.code()==400){
                    Toast.makeText(MainActivity.this, "WTF", Toast.LENGTH_LONG).show();
                }

            }

            @Override
            public void onFailure(Call<HashMap<String,Integer>> call, Throwable t) {

                Toast.makeText(MainActivity.this, "No hay conexión", Toast.LENGTH_LONG).show();

            }
        });




    }

    private void getMetroEst(HashMap<String, String> busqueda) {

        //Crear la instancia Retrofit

        Retrofit.Builder builder = new Retrofit.Builder().baseUrl("" + baseUrl).addConverterFactory(GsonConverterFactory.create());
        Retrofit retrofit = builder.build();

        //Obtenemos el cliente y llamamos un request al objeto
        parkClient client = retrofit.create(parkClient.class);
        Call<List<Estacionamiento>> call = client.getMetro(busqueda);


        call.enqueue(new Callback<List<Estacionamiento>>() {
            @Override
            public void onResponse(Call<List<Estacionamiento>> call, Response<List<Estacionamiento>> response) {

                if (response.code() == 200) {

                    estacionamientos = response.body();
                    Toast.makeText(MainActivity.this, "Datos obtenidos correctamente", Toast.LENGTH_LONG).show();
                    Intent i = new Intent(MainActivity.this,MapsActivityMetro.class);
                    startActivity(i);

                } else if (response.code() == 400) {
                    Toast.makeText(MainActivity.this, "WTF", Toast.LENGTH_LONG).show();
                }

            }

            @Override
            public void onFailure(Call<List<Estacionamiento>> call, Throwable t) {

                Toast.makeText(MainActivity.this, "No hay conexión", Toast.LENGTH_LONG).show();

            }
        });

    }

}
