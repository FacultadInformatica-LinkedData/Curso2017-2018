package com.upm.websemantica.parkme.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.jena.query.QueryExecution;
import org.apache.jena.query.QueryExecutionFactory;
import org.apache.jena.query.QuerySolution;
import org.apache.jena.query.ResultSet;
import org.apache.jena.rdf.model.RDFNode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.upm.websemantica.parkme.model.Estacionamiento;

@Service
public class SparqlService {

	@Autowired
	private DBPediaService dbpediaservice;

	public HashMap<String,Integer> numeroDePlazasPorDistrito  (String ZonaEstacionamiento) {

		HashMap<String,Integer> distrito_estacionamientos = new HashMap<>();

		String query ="SELECT (SUM(?Plazas) AS ?suma)   ?distrito  WHERE {\r\n" + 
				"\r\n" + 
				"?Estacionamiento a <http://www.semanticweb.org/group03/ontology#"+ZonaEstacionamiento+"> .\r\n" + 
				"?Estacionamiento <http://vocab.linkeddata.es/datosabiertos/def/sector-publico/territorio#distrito> ?distrito  .\r\n" + 
				"\r\n" + 
				"OPTIONAL { ?Estacionamiento <http://www.semanticweb.org/group03/ontology#numeroDePlazas> ?Plazas } .	\r\n" + 
				"\r\n" + 
				"			} GROUP BY ?distrito" ;


		QueryExecution qexec = QueryExecutionFactory.sparqlService("http://localhost:8890/sparql", query);


		try {
			ResultSet results1 = qexec.execSelect();
			for (; results1.hasNext();) {
				QuerySolution a = results1.next();
				RDFNode num = a.get("suma");
				RDFNode distrito1 = a.get("distrito");

				String aux = num.toString().split("http")[0];

				distrito_estacionamientos.put(distrito1.toString().split("http://www.semanticweb.org/group03/resource/")[1].replaceAll("\\+", " "), Integer.valueOf(aux.substring(0, aux.length()-2)));

			}
		}
		finally {
			qexec.close();
		}

		return distrito_estacionamientos;
	}

	public HashMap<String,Integer> numeroDePlazasPorDistrito  () {

		HashMap<String,Integer> distrito_estacionamientos = new HashMap<>();

		String query ="SELECT (SUM(?Plazas) AS ?suma)  ?distrito  WHERE {\r\n" + 
				"\r\n" + 
				"?E <http://www.w3.org/2000/01/rdf-schema#subClassOf> <http://www.semanticweb.org/group03/ontology#Estacionamiento> .\r\n" + 
				"?Estacionamiento a ?E .\r\n" + 
				"?Estacionamiento <http://vocab.linkeddata.es/datosabiertos/def/sector-publico/territorio#distrito> ?distrito  . \r\n" + 
				"OPTIONAL { ?Estacionamiento <http://www.semanticweb.org/group03/ontology#numeroDePlazas> ?Plazas } .				\r\n" + 
				"\r\n" + 
				"} GROUP BY ?distrito" ;


		QueryExecution qexec = QueryExecutionFactory.sparqlService("http://localhost:8890/sparql", query);


		try {
			ResultSet results1 = qexec.execSelect();
			for (; results1.hasNext();) {
				QuerySolution a = results1.next();
				RDFNode num = a.get("suma");
				RDFNode distrito1 = a.get("distrito");

				if (num!=null 	) {
					String aux = num.toString().split("http")[0];
					distrito_estacionamientos.put(distrito1.toString().split("http://www.semanticweb.org/group03/resource/")[1].replaceAll("\\+", " "), Integer.valueOf(aux.substring(0, aux.length()-2)));
				}
			}
		}
		finally {
			qexec.close();
		}

		return distrito_estacionamientos;
	}

	public HashMap<String,Integer> numeroDeParquimetrosPorDistrito  () {

		HashMap<String,Integer> distrito_parquimetros = new HashMap<>();

		String query ="SELECT ?distrito (COUNT(?Parquimetro) AS ?P)    WHERE {\r\n" + 
				"   ?Parquimetro a <http://www.semanticweb.org/group03/ontology#Parquimetro> .\r\n" + 
				"   ?Parquimetro <http://vocab.linkeddata.es/datosabiertos/def/sector-publico/territorio#distrito> ?distrito  . \r\n" + 
				"} GROUP BY ?distrito" ;


		QueryExecution qexec = QueryExecutionFactory.sparqlService("http://localhost:8890/sparql", query);

		try {
			ResultSet results1 = qexec.execSelect();
			for (; results1.hasNext();) {
				QuerySolution a = results1.next();
				RDFNode num = a.get("P");
				RDFNode distrito1 = a.get("distrito");

				String aux = num.toString().split("http")[0];

				distrito_parquimetros.put(distrito1.toString().split("http://www.semanticweb.org/group03/resource/")[1].replaceAll("\\+", " "), Integer.valueOf(aux.substring(0, aux.length()-2)));

			}
		}
		finally {
			qexec.close();
		}

		return distrito_parquimetros;
	}




	public List<Estacionamiento> direccionDeEstacionamiento (String tipo, String direccion, int numero) {

		boolean igual = false;

		String query = "SELECT distinct ?Estacionamiento ?Tipo ?Forma_Aparcar ?Plazas ?Tipo_Pto_Recarga ?Tipo_Conector ?Conectores ?Direccion_Estacionamiento ?Direccion_Parquimetro WHERE {\r\n" + 
				"   ?E <http://www.w3.org/2000/01/rdf-schema#subClassOf> <http://www.semanticweb.org/group03/ontology#Estacionamiento> .\r\n" + 
				"   ?Estacionamiento a ?E .\r\n" + 
				"   OPTIONAL { ?Estacionamiento <http://www.semanticweb.org/group03/ontology#tipoEstacionamiento> ?Tipo } .\r\n" + 
				"   OPTIONAL { ?Estacionamiento <http://www.semanticweb.org/group03/ontology#formaDeAparcamiento> ?Forma_Aparcar } . \r\n" + 
				"   OPTIONAL { ?Estacionamiento <http://www.semanticweb.org/group03/ontology#numeroDePlazas> ?Plazas } .\r\n" + 
				"   ?Estacionamiento <http://www.w3.org/2006/vcard/ns#hasAddress> ?D .\r\n" + 
				"   ?D <http://www.w3.org/2006/vcard/ns#street-address> ?Direccion_Estacionamiento .\r\n" + 
				"   OPTIONAL { ?Estacionamiento <http://www.semanticweb.org/group03/ontology#cercaDe> ?Parquimetro .\r\n" + 
				"              ?Parquimetro <http://www.w3.org/2006/vcard/ns#hasAddress> ?D2 .\r\n" + 
				"              ?D2 <http://www.w3.org/2006/vcard/ns#street-address> ?Direccion_Parquimetro } .\r\n" + 
				"\r\n" + 
				"   OPTIONAL { ?Estacionamiento <http://www.semanticweb.org/group03/ontology#tipoDePuntoRecarga> ?Tipo_Pto_Recarga } .\r\n" + 
				"   OPTIONAL { ?Estacionamiento <http://www.semanticweb.org/group03/ontology#tipoDeConector> ?Tipo_Conector } .\r\n" + 
				"   OPTIONAL { ?Estacionamiento <http://www.semanticweb.org/group03/ontology#numeroDeConectores> ?Conectores } .\r\n" + 
				"\r\n" + 
				"   FILTER regex(lcase(str(?Direccion_Estacionamiento )), \""+direccion.toLowerCase()+"\")\r\n" + 
				"   FILTER regex(lcase(str(?Direccion_Estacionamiento )), \""+tipo.toLowerCase()+"\")\r\n" +
				"}";

		QueryExecution qexec = QueryExecutionFactory.sparqlService("http://localhost:8890/sparql", query);

		List<Estacionamiento> estacionamientos = new ArrayList<>();

		try {
			ResultSet results1 = qexec.execSelect();

			for (; results1.hasNext();) {

				QuerySolution a = results1.next();

				RDFNode tipo_park = a.get("Tipo");
				RDFNode forma_Aparcar = a.get("Forma_Aparcar");
				RDFNode plazas = a.get("Plazas");
				RDFNode tipo_Pto_Recarga = a.get("Tipo_Pto_Recarga");
				RDFNode tipo_Conector = a.get("Tipo_Conector");
				RDFNode conectores = a.get("Conectores");
				RDFNode direccion_Estacionamiento = a.get("Direccion_Estacionamiento");
				RDFNode direccion_Parquimetro = a.get("Direccion_Parquimetro");

				Estacionamiento estacionamiento = new Estacionamiento();

				if(tipo_park != null) {
					estacionamiento.setTipo(tipo_park.toString());
				}
				if(forma_Aparcar != null) {
					estacionamiento.setForma_de_aparcar(forma_Aparcar.toString());
				}
				if(plazas != null) {
					String aux = plazas.toString().split("http")[0];	
					estacionamiento.setPlazas(Integer.valueOf(aux.substring(0, aux.length()-2)));
				}
				if(tipo_Pto_Recarga != null) {
					estacionamiento.setTipo_pto_recarga(tipo_Pto_Recarga.toString());
				}
				if(tipo_Conector != null) {
					estacionamiento.setTipo_conector(tipo_Conector.toString());
				}
				if(conectores != null) {
					String aux = conectores.toString().split("http")[0];					
					estacionamiento.setConectores(Integer.valueOf(aux.substring(0, aux.length()-2)));
				}
				if(direccion_Estacionamiento != null) {
					estacionamiento.setDireccion(direccion_Estacionamiento.toString());
					String num = direccion_Estacionamiento.toString().replaceAll("[^0-9]", "");

					if(Integer.valueOf(num).equals(numero)) {
						igual = true;
					}

				}
				if(direccion_Parquimetro != null) {
					estacionamiento.setDireccion_parquimetro(direccion_Parquimetro.toString());
				}

				if(igual) {
					estacionamientos = new ArrayList<>();
					estacionamientos.add(estacionamiento);
					break;
				}else {
					estacionamientos.add(estacionamiento);
				}



			}
		}
		finally {
			qexec.close();
		}

		return estacionamientos;

	}

	public List<Estacionamiento> direccionDeEstacionamiento (String tipo, String direccion, int numero, String ZonaEstacionamiento) {

		boolean igual = false;

		String query = "SELECT distinct ?Estacionamiento ?Tipo ?Forma_Aparcar ?Plazas ?Tipo_Pto_Recarga ?Tipo_Conector ?Conectores ?Direccion_Estacionamiento ?Direccion_Parquimetro WHERE {\r\n" + 
				"   ?E <http://www.w3.org/2000/01/rdf-schema#subClassOf> <http://www.semanticweb.org/group03/ontology#Estacionamiento> .\r\n" + 
				"?Estacionamiento a <http://www.semanticweb.org/group03/ontology#"+ZonaEstacionamiento+"> .\r\n" + 
				"   OPTIONAL { ?Estacionamiento <http://www.semanticweb.org/group03/ontology#tipoEstacionamiento> ?Tipo } .\r\n" + 
				"   OPTIONAL { ?Estacionamiento <http://www.semanticweb.org/group03/ontology#formaDeAparcamiento> ?Forma_Aparcar } . \r\n" + 
				"   OPTIONAL { ?Estacionamiento <http://www.semanticweb.org/group03/ontology#numeroDePlazas> ?Plazas } .\r\n" + 
				"   ?Estacionamiento <http://www.w3.org/2006/vcard/ns#hasAddress> ?D .\r\n" + 
				"   ?D <http://www.w3.org/2006/vcard/ns#street-address> ?Direccion_Estacionamiento .\r\n" + 
				"   OPTIONAL { ?Estacionamiento <http://www.semanticweb.org/group03/ontology#cercaDe> ?Parquimetro .\r\n" + 
				"              ?Parquimetro <http://www.w3.org/2006/vcard/ns#hasAddress> ?D2 .\r\n" + 
				"              ?D2 <http://www.w3.org/2006/vcard/ns#street-address> ?Direccion_Parquimetro } .\r\n" + 
				"\r\n" + 
				"   OPTIONAL { ?Estacionamiento <http://www.semanticweb.org/group03/ontology#tipoDePuntoRecarga> ?Tipo_Pto_Recarga } .\r\n" + 
				"   OPTIONAL { ?Estacionamiento <http://www.semanticweb.org/group03/ontology#tipoDeConector> ?Tipo_Conector } .\r\n" + 
				"   OPTIONAL { ?Estacionamiento <http://www.semanticweb.org/group03/ontology#numeroDeConectores> ?Conectores } .\r\n" + 
				"\r\n" + 
				"   FILTER regex(lcase(str(?Direccion_Estacionamiento )), \""+direccion.toLowerCase()+"\")\r\n" + 
				"   FILTER regex(lcase(str(?Direccion_Estacionamiento )), \""+tipo.toLowerCase()+"\")\r\n" +
				"}";

		QueryExecution qexec = QueryExecutionFactory.sparqlService("http://localhost:8890/sparql", query);

		List<Estacionamiento> estacionamientos = new ArrayList<>();

		try {
			ResultSet results1 = qexec.execSelect();

			for (; results1.hasNext();) {

				QuerySolution a = results1.next();

				RDFNode tipo_park = a.get("Tipo");
				RDFNode forma_Aparcar = a.get("Forma_Aparcar");
				RDFNode plazas = a.get("Plazas");
				RDFNode tipo_Pto_Recarga = a.get("Tipo_Pto_Recarga");
				RDFNode tipo_Conector = a.get("Tipo_Conector");
				RDFNode conectores = a.get("Conectores");
				RDFNode direccion_Estacionamiento = a.get("Direccion_Estacionamiento");
				RDFNode direccion_Parquimetro = a.get("Direccion_Parquimetro");

				Estacionamiento estacionamiento = new Estacionamiento();

				if(tipo_park != null) {
					estacionamiento.setTipo(tipo_park.toString());
				}
				if(forma_Aparcar != null) {
					estacionamiento.setForma_de_aparcar(forma_Aparcar.toString());
				}
				if(plazas != null) {
					String aux = plazas.toString().split("http")[0];	
					estacionamiento.setPlazas(Integer.valueOf(aux.substring(0, aux.length()-2)));
				}
				if(tipo_Pto_Recarga != null) {
					estacionamiento.setTipo_pto_recarga(tipo_Pto_Recarga.toString());
				}
				if(tipo_Conector != null) {
					estacionamiento.setTipo_conector(tipo_Conector.toString());
				}
				if(conectores != null) {
					String aux = conectores.toString().split("http")[0];					
					estacionamiento.setConectores(Integer.valueOf(aux.substring(0, aux.length()-2)));
				}
				if(direccion_Estacionamiento != null) {
					estacionamiento.setDireccion(direccion_Estacionamiento.toString());
					String num = direccion_Estacionamiento.toString().replaceAll("[^0-9]", "");

					if(Integer.valueOf(num).equals(numero)) {
						igual = true;
					}

				}
				if(direccion_Parquimetro != null) {
					estacionamiento.setDireccion_parquimetro(direccion_Parquimetro.toString());
				}

				if(igual) {
					estacionamientos = new ArrayList<>();
					estacionamientos.add(estacionamiento);
					break;
				}else {
					estacionamientos.add(estacionamiento);
				}



			}
		}
		finally {
			qexec.close();
		}

		return estacionamientos;

	}

	public List<String> direccionDeParquimetro (String tipo, String direccion, int numero) {

		boolean igual = false;

		String query = "SELECT distinct ?Direccion_Parquimetro WHERE {\r\n" + 
				"  \r\n" + 
				"   ?Parquimetro a <http://www.semanticweb.org/group03/ontology#Parquimetro> .\r\n" + 
				"   ?Parquimetro <http://www.w3.org/2006/vcard/ns#hasAddress> ?D2 .\r\n" + 
				"   ?D2 <http://www.w3.org/2006/vcard/ns#street-address> ?Direccion_Parquimetro .\r\n" + 
				"\r\n" + 
				"   FILTER regex(lcase(str(?Direccion_Parquimetro)), \""+direccion.toLowerCase()+"\")\r\n" + 
				"   FILTER regex(lcase(str(?Direccion_Parquimetro)), \""+tipo.toLowerCase()+"\")\r\n" +
				"}";

		QueryExecution qexec = QueryExecutionFactory.sparqlService("http://localhost:8890/sparql", query);

		List<String> parquimetros = new ArrayList<>();

		try {
			ResultSet results1 = qexec.execSelect();

			for (; results1.hasNext();) {

				QuerySolution a = results1.next();

				RDFNode direccion_Parquimetro = a.get("Direccion_Parquimetro");

				if(direccion_Parquimetro != null) {
					parquimetros.add(direccion_Parquimetro.toString());

					String num = direccion_Parquimetro.toString().replaceAll("[^0-9]", "");

					if(Integer.valueOf(num).equals(numero)) {
						igual = true;
					}

				}

				if(igual) {
					parquimetros = new ArrayList<>();
					parquimetros.add(direccion_Parquimetro.toString());
					break;
				}

			}

		}
		finally {
			qexec.close();
		}

		return parquimetros;

	}

	public List<Estacionamiento> estacionamientoDeMetro (String estacion_de_metro) {

		HashMap<String, String> metro_direccion = dbpediaservice.getMetro_direccion();
		String direccion =  metro_direccion.get(estacion_de_metro);
		
		List<String> direcciones  = new ArrayList<>();
		if(direccion.contains(" con ")) {
			direcciones.add(direccion.split(" con ")[0]);
			direcciones.add(direccion.split(" con ")[1]);
		}else {
			direcciones.add(direccion);
		}
		
		String numero = direccion.toString().replaceAll("[^0-9]", "");
		
		HashMap<String, String> distrito_metro = dbpediaservice.getDistrito_metro();
		String distrito =  distrito_metro.get(estacion_de_metro);
		
		String query = "SELECT ?Estacionamiento  ?distrito ?Tipo ?Forma_Aparcar ?Plazas ?Tipo_Pto_Recarga ?Tipo_Conector ?Conectores ?Direccion_Estacionamiento ?Direccion_Parquimetro WHERE {\r\n" + 
				"   ?E <http://www.w3.org/2000/01/rdf-schema#subClassOf> <http://www.semanticweb.org/group03/ontology#Estacionamiento> .\r\n" + 
				"   ?Estacionamiento a ?E .\r\n" + 
				"\r\n" + 
				"   ?Estacionamiento <http://vocab.linkeddata.es/datosabiertos/def/sector-publico/territorio#distrito> ?distrito .\r\n" + 
				"   ?distrito <http://www.w3.org/2002/07/owl#sameAs> <"+distrito+"> .\r\n" + 
				"\r\n" + 
				"   OPTIONAL { ?Estacionamiento <http://www.semanticweb.org/group03/ontology#tipoEstacionamiento> ?Tipo } .\r\n" + 
				"   OPTIONAL { ?Estacionamiento <http://www.semanticweb.org/group03/ontology#formaDeAparcamiento> ?Forma_Aparcar } . \r\n" + 
				"   OPTIONAL { ?Estacionamiento <http://www.semanticweb.org/group03/ontology#numeroDePlazas> ?Plazas } .\r\n" + 
				"   ?Estacionamiento <http://www.w3.org/2006/vcard/ns#hasAddress> ?D .\r\n" + 
				"   ?D <http://www.w3.org/2006/vcard/ns#street-address> ?Direccion_Estacionamiento .\r\n" + 
				"   OPTIONAL { ?Estacionamiento <http://www.semanticweb.org/group03/ontology#cercaDe> ?Parquimetro .\r\n" + 
				"              ?Parquimetro <http://www.w3.org/2006/vcard/ns#hasAddress> ?D2 .\r\n" + 
				"              ?D2 <http://www.w3.org/2006/vcard/ns#street-address> ?Direccion_Parquimetro } .\r\n" + 
				"\r\n" + 
				"   OPTIONAL { ?Estacionamiento <http://www.semanticweb.org/group03/ontology#tipoDePuntoRecarga> ?Tipo_Pto_Recarga } .\r\n" + 
				"   OPTIONAL { ?Estacionamiento <http://www.semanticweb.org/group03/ontology#tipoDeConector> ?Tipo_Conector } .\r\n" + 
				"   OPTIONAL { ?Estacionamiento <http://www.semanticweb.org/group03/ontology#numeroDeConectores> ?Conectores } .\r\n" + 
				"\r\n" + 
				"\r\n" + 
				"}";

		QueryExecution qexec = QueryExecutionFactory.sparqlService("http://localhost:8890/sparql", query);

		List<Estacionamiento> estacionamientos = new ArrayList<>();

		boolean igual = false; 
		try {
			ResultSet results1 = qexec.execSelect();

			for (; results1.hasNext();) {

				QuerySolution a = results1.next();

				RDFNode tipo_park = a.get("Tipo");
				RDFNode forma_Aparcar = a.get("Forma_Aparcar");
				RDFNode plazas = a.get("Plazas");
				RDFNode tipo_Pto_Recarga = a.get("Tipo_Pto_Recarga");
				RDFNode tipo_Conector = a.get("Tipo_Conector");
				RDFNode conectores = a.get("Conectores");
				RDFNode direccion_Estacionamiento = a.get("Direccion_Estacionamiento");
				RDFNode direccion_Parquimetro = a.get("Direccion_Parquimetro");

				
				Estacionamiento estacionamiento = new Estacionamiento();

				if(tipo_park != null) {
					estacionamiento.setTipo(tipo_park.toString());
				}
				if(forma_Aparcar != null) {
					estacionamiento.setForma_de_aparcar(forma_Aparcar.toString());
				}
				if(plazas != null) {
					String aux = plazas.toString().split("http")[0];	
					estacionamiento.setPlazas(Integer.valueOf(aux.substring(0, aux.length()-2)));
				}
				if(tipo_Pto_Recarga != null) {
					estacionamiento.setTipo_pto_recarga(tipo_Pto_Recarga.toString());
				}
				if(tipo_Conector != null) {
					estacionamiento.setTipo_conector(tipo_Conector.toString());
				}
				if(conectores != null) {
					String aux = conectores.toString().split("http")[0];					
					estacionamiento.setConectores(Integer.valueOf(aux.substring(0, aux.length()-2)));
				}
				
				boolean cont = false;
				
				if(direccion_Estacionamiento != null) {
								
					for(String d: direcciones) {
						if(direccion_Estacionamiento.toString().contains(d)) {
							estacionamiento.setDireccion(direccion_Estacionamiento.toString());
							String num = direccion_Estacionamiento.toString().replaceAll("[^0-9]", "");

							if(Integer.valueOf(num).equals(numero)) {
								igual = true;
							}
							
							cont = false;
						}else {
							cont = true;
						}
					}
					
					if(cont)
						continue;

				}
				if(direccion_Parquimetro != null) {
					estacionamiento.setDireccion_parquimetro(direccion_Parquimetro.toString());
				}

				if(igual) {
					estacionamientos = new ArrayList<>();
					estacionamientos.add(estacionamiento);
					break;
				}else {
					estacionamientos.add(estacionamiento);
				}
			}
		}
		finally {
			qexec.close();
		}

		return estacionamientos;


	}


}
