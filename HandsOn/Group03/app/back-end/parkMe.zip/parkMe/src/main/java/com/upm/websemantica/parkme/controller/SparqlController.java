package com.upm.websemantica.parkme.controller;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.upm.websemantica.parkme.model.Estacionamiento;
import com.upm.websemantica.parkme.services.DBPediaService;
import com.upm.websemantica.parkme.services.SparqlService;

@Controller
@RequestMapping("parkMe/api/SparqlController")
public class SparqlController {

	@Autowired
	private SparqlService sparqlService;
	@Autowired
	private DBPediaService dbPediaService;

	@RequestMapping(value = "dbPediaService", method=RequestMethod.GET)
	public ResponseEntity<HashMap<String,String>> dbPediaService() {



		return new ResponseEntity<HashMap<String,String>> (dbPediaService.getMetro_direccion(),HttpStatus.OK);
	}

	@RequestMapping(value = "numeroDeParquimetrosPorDistrito", method=RequestMethod.GET)
	public ResponseEntity<HashMap<String,Integer>> numeroDeParquimetrosPorDistrito() {
		return new ResponseEntity<HashMap<String,Integer>> (sparqlService.numeroDeParquimetrosPorDistrito(),HttpStatus.OK);
	}

	@RequestMapping(value = "numeroDePlazasPorDistrito", method=RequestMethod.GET)
	public ResponseEntity<HashMap<String,Integer>> numeroDePlazasPorDistrito(@RequestParam(value="Zona", required=false) String zona) {
		if(zona==null) 
			return new ResponseEntity<HashMap<String,Integer>> (sparqlService.numeroDePlazasPorDistrito(),HttpStatus.OK);
		else
			return new ResponseEntity<HashMap<String,Integer>> (sparqlService.numeroDePlazasPorDistrito(zona),HttpStatus.OK);

	}

	@RequestMapping(value = "direccionDeEstacionamiento", method=RequestMethod.GET)
	public ResponseEntity<List<Estacionamiento>> direccionDeEstacionamiento(
			@RequestParam(value="tipo", required=true) String tipo, 
			@RequestParam(value="direccion", required=true) String direccion, 
			@RequestParam(value="numero", required=true) String numero,
			@RequestParam(value="Zona", required=false) String zona) {

		if(zona==null) 
			return new ResponseEntity<List<Estacionamiento>> (sparqlService.direccionDeEstacionamiento(tipo, direccion, Integer.valueOf(numero)),HttpStatus.OK);
		else
			return new ResponseEntity<List<Estacionamiento>> (sparqlService.direccionDeEstacionamiento(tipo, direccion, Integer.valueOf(numero),zona),HttpStatus.OK);

	}

	@RequestMapping(value = "direccionDeParquimetro", method=RequestMethod.GET)
	public ResponseEntity<List<String>> direccionDeParquimetro(
			@RequestParam(value="tipo", required=true) String tipo, 
			@RequestParam(value="direccion", required=true) String direccion, 
			@RequestParam(value="numero", required=true) String numero) {

		List<String> response = sparqlService.direccionDeParquimetro(tipo, direccion, Integer.valueOf(numero));
		if(response!=null)
			return new ResponseEntity<List<String>> (response,HttpStatus.OK);
		else
			return new ResponseEntity<List<String>> (HttpStatus.BAD_REQUEST);

	}

	@RequestMapping(value = "estacionamientoDeMetro", method=RequestMethod.GET)
	public ResponseEntity<List<Estacionamiento>> estacionamientoDeMetro(
			@RequestParam(value="estacion", required=true) String estacion) {

		return new ResponseEntity<List<Estacionamiento>> (sparqlService.estacionamientoDeMetro(estacion),HttpStatus.OK);

	}
}