package com.upm.websemantica.parkme.model;

public class Estacionamiento {

	private String direccion;
	private String direccion_parquimetro;
	private String tipo;
	private int plazas;
	private String forma_de_aparcar;
	private String tipo_pto_recarga;
	private String tipo_conector;
	private int conectores;
	
	
	
	public String getDireccion() {
		return direccion;
	}
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	public String getDireccion_parquimetro() {
		return direccion_parquimetro;
	}
	public void setDireccion_parquimetro(String direccion_parquimetro) {
		this.direccion_parquimetro = direccion_parquimetro;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	public int getPlazas() {
		return plazas;
	}
	public void setPlazas(int plazas) {
		this.plazas = plazas;
	}
	public String getForma_de_aparcar() {
		return forma_de_aparcar;
	}
	public void setForma_de_aparcar(String forma_de_aparcar) {
		this.forma_de_aparcar = forma_de_aparcar;
	}
	public String getTipo_pto_recarga() {
		return tipo_pto_recarga;
	}
	public void setTipo_pto_recarga(String tipo_pto_recarga) {
		this.tipo_pto_recarga = tipo_pto_recarga;
	}
	public String getTipo_conector() {
		return tipo_conector;
	}
	public void setTipo_conector(String tipo_conector) {
		this.tipo_conector = tipo_conector;
	}
	public int getConectores() {
		return conectores;
	}
	public void setConectores(int conectores) {
		this.conectores = conectores;
	}
	
	
}
