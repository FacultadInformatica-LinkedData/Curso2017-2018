package com.upm.websemantica.parkme.services;

import java.util.HashMap;
import org.apache.jena.query.QueryExecution;
import org.apache.jena.query.QueryExecutionFactory;
import org.apache.jena.query.QuerySolution;
import org.apache.jena.query.ResultSet;
import org.apache.jena.rdf.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DBPediaService {

	private HashMap<String,String> distrito_metro;
	private HashMap<String,String> metro_direccion;
	
	@Autowired
	public void getDBpediaresources () {
		String query = "select distinct ?Distrito ?Estacion_de_metro ?Direccion_estacion_de_metro where {\r\n" + 
				"	{\r\n" + 
				"		?Estacion_de_metro <http://es.dbpedia.org/property/sector> ?Distrito .\r\n" + 
				"                ?Estacion_de_metro <http://dbpedia.org/ontology/address> ?Direccion_estacion_de_metro.\r\n" + 
				"		FILTER regex(str(?Distrito), \"Arganzuela\")\r\n" + 
				"	}\r\n" + 
				"UNION \r\n" + 
				"	{\r\n" + 
				"		?Estacion_de_metro <http://es.dbpedia.org/property/sector> ?Distrito .\r\n" + 
				"                ?Estacion_de_metro <http://dbpedia.org/ontology/address> ?Direccion_estacion_de_metro.\r\n" + 
				"		FILTER regex(str(?Distrito), \"Carabanchel\")\r\n" + 
				"	}\r\n" + 
				"UNION \r\n" + 
				"	{\r\n" + 
				"		?Estacion_de_metro <http://es.dbpedia.org/property/sector> ?Distrito .\r\n" + 
				"                ?Estacion_de_metro <http://dbpedia.org/ontology/address> ?Direccion_estacion_de_metro.\r\n" + 
				"		FILTER regex(str(?Distrito), \"Madrid\")\r\n" + 
				"	}\r\n" + 
				"UNION \r\n" + 
				"	{\r\n" + 
				"		?Estacion_de_metro <http://es.dbpedia.org/property/sector> ?Distrito .\r\n" + 
				"                ?Estacion_de_metro <http://dbpedia.org/ontology/address> ?Direccion_estacion_de_metro.\r\n" + 
				"		FILTER regex(str(?Distrito), \"Latina\")\r\n" + 
				"	}\r\n" + 
				"UNION \r\n" + 
				"	{\r\n" + 
				"		?Estacion_de_metro <http://es.dbpedia.org/property/sector> ?Distrito .\r\n" + 
				"                ?Estacion_de_metro <http://dbpedia.org/ontology/address> ?Direccion_estacion_de_metro.\r\n" + 
				"		FILTER regex(str(?Distrito), \"Tetuán\")\r\n" + 
				"	}\r\n" + 
				"UNION \r\n" + 
				"	{\r\n" + 
				"		?Estacion_de_metro <http://es.dbpedia.org/property/sector> ?Distrito .\r\n" + 
				"                ?Estacion_de_metro <http://dbpedia.org/ontology/address> ?Direccion_estacion_de_metro.\r\n" + 
				"		FILTER regex(str(?Distrito), \"Tetuan\")\r\n" + 
				"	}\r\n" + 
				"UNION \r\n" + 
				"	{\r\n" + 
				"		?Estacion_de_metro <http://es.dbpedia.org/property/sector> ?Distrito .\r\n" + 
				"                ?Estacion_de_metro <http://dbpedia.org/ontology/address> ?Direccion_estacion_de_metro.\r\n" + 
				"		FILTER regex(str(?Distrito), \"Salamanca\")\r\n" + 
				"	}\r\n" + 
				"UNION \r\n" + 
				"	{\r\n" + 
				"		?Estacion_de_metro <http://es.dbpedia.org/property/sector> ?Distrito .\r\n" + 
				"                ?Estacion_de_metro <http://dbpedia.org/ontology/address> ?Direccion_estacion_de_metro.\r\n" + 
				"		FILTER regex(str(?Distrito), \"Villaverde\")\r\n" + 
				"	}\r\n" + 
				"UNION \r\n" + 
				"	{\r\n" + 
				"		?Estacion_de_metro <http://es.dbpedia.org/property/sector> ?Distrito .\r\n" + 
				"                ?Estacion_de_metro <http://dbpedia.org/ontology/address> ?Direccion_estacion_de_metro.\r\n" + 
				"		FILTER regex(str(?Distrito), \"San_Blas\")\r\n" + 
				"	}\r\n" + 
				"UNION \r\n" + 
				"	{\r\n" + 
				"		?Estacion_de_metro <http://es.dbpedia.org/property/sector> ?Distrito .\r\n" + 
				"                ?Estacion_de_metro <http://dbpedia.org/ontology/address> ?Direccion_estacion_de_metro.\r\n" + 
				"		FILTER regex(str(?Distrito), \"Moratalaz\")\r\n" + 
				"	}\r\n" + 
				"UNION \r\n" + 
				"	{\r\n" + 
				"		?Estacion_de_metro <http://es.dbpedia.org/property/sector> ?Distrito .\r\n" + 
				"                ?Estacion_de_metro <http://dbpedia.org/ontology/address> ?Direccion_estacion_de_metro.\r\n" + 
				"		FILTER regex(str(?Distrito), \"Ciudad_Lineal\")\r\n" + 
				"	}\r\n" + 
				"UNION \r\n" + 
				"	{\r\n" + 
				"		?Estacion_de_metro <http://es.dbpedia.org/property/sector> ?Distrito .\r\n" + 
				"                ?Estacion_de_metro <http://dbpedia.org/ontology/address> ?Direccion_estacion_de_metro.\r\n" + 
				"		FILTER regex(str(?Distrito), \"Villa_de_Vallecas\")\r\n" + 
				"	}\r\n" + 
				"UNION \r\n" + 
				"	{\r\n" + 
				"		?Estacion_de_metro <http://es.dbpedia.org/property/sector> ?Distrito .\r\n" + 
				"                ?Estacion_de_metro <http://dbpedia.org/ontology/address> ?Direccion_estacion_de_metro.\r\n" + 
				"		FILTER regex(str(?Distrito), \"Usera\")\r\n" + 
				"	}\r\n" + 
				"UNION \r\n" + 
				"	{\r\n" + 
				"		?Estacion_de_metro <http://es.dbpedia.org/property/sector> ?Distrito .\r\n" + 
				"                ?Estacion_de_metro <http://dbpedia.org/ontology/address> ?Direccion_estacion_de_metro.\r\n" + 
				"		FILTER regex(str(?Distrito), \"Puente_de_Vallecas\")\r\n" + 
				"	}\r\n" + 
				"UNION \r\n" + 
				"	{\r\n" + 
				"		?Estacion_de_metro <http://es.dbpedia.org/property/sector> ?Distrito .\r\n" + 
				"                ?Estacion_de_metro <http://dbpedia.org/ontology/address> ?Direccion_estacion_de_metro.\r\n" + 
				"		FILTER regex(str(?Distrito), \"Moncloa\")\r\n" + 
				"	}\r\n" + 
				"UNION \r\n" + 
				"	{\r\n" + 
				"		?Estacion_de_metro <http://es.dbpedia.org/property/sector> ?Distrito .\r\n" + 
				"                ?Estacion_de_metro <http://dbpedia.org/ontology/address> ?Direccion_estacion_de_metro.\r\n" + 
				"		FILTER regex(str(?Distrito), \"Hortaleza\")\r\n" + 
				"	}\r\n" + 
				"UNION \r\n" + 
				"	{\r\n" + 
				"		?Estacion_de_metro <http://es.dbpedia.org/property/sector> ?Distrito .\r\n" + 
				"                ?Estacion_de_metro <http://dbpedia.org/ontology/address> ?Direccion_estacion_de_metro.\r\n" + 
				"		FILTER regex(str(?Distrito), \"Fuencarral\")\r\n" + 
				"	}\r\n" + 
				"UNION \r\n" + 
				"	{\r\n" + 
				"		?Estacion_de_metro <http://es.dbpedia.org/property/sector> ?Distrito .\r\n" + 
				"                ?Estacion_de_metro <http://dbpedia.org/ontology/address> ?Direccion_estacion_de_metro.\r\n" + 
				"		FILTER regex(str(?Distrito), \"Barajas\")\r\n" + 
				"	}\r\n" + 
				"} ";

		


		QueryExecution qexec = QueryExecutionFactory.sparqlService("http://es.dbpedia.org/sparql", query);

		HashMap<String,String> distrito_metro = new HashMap<String,String>();
		HashMap<String,String> metro_direccion = new HashMap<String,String>();


		try {
			ResultSet results1 = qexec.execSelect();

			for (; results1.hasNext();) {

				QuerySolution a = results1.next();
				RDFNode distrito = a.get("Distrito");
				RDFNode estacion_de_metro = a.get("Estacion_de_metro");
				RDFNode direccion_estacion_de_metro = a.get("Direccion_estacion_de_metro");

//				System.out.println(String.format( "%10s		%10s	%10s",distrito.toString(),estacion_de_metro.toString(),direccion_estacion_de_metro.toString()));
//				System.out.println(String.format( "%10s		%10s	%10s",distrito.toString(),estacion_de_metro.toString(),direccion_estacion_de_metro.toString().substring(0, direccion_estacion_de_metro.toString().length()-3)));
				
//				String distrito_name = distrito.toString().split("http://es.dbpedia.org/resource/")[1];
				String metro_name = estacion_de_metro.toString().split("http://es.dbpedia.org/resource/")[1].replaceAll("_", " ");

				
				distrito_metro.put(metro_name,distrito.toString());
				metro_direccion.put(metro_name, direccion_estacion_de_metro.toString().substring(0, direccion_estacion_de_metro.toString().length()-3));
			}
		}
		finally {
			qexec.close();
		}
		
		this.distrito_metro = distrito_metro;
		this.metro_direccion = metro_direccion;

	}

	public HashMap<String, String> getDistrito_metro() {
		return distrito_metro;
	}

	public HashMap<String, String> getMetro_direccion() {
		return metro_direccion;
	}
	
	
}