package com.upm.websemantica.parkme;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParkmeApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParkmeApplication.class, args);
	}
}
