// ////Start Google Maps ////
//   function initialize() {
//     var myOptions = {
//   	zoom: 14,
//   	center: new google.maps.LatLng(40.416775,-3.703790),
//   	mapTypeId: google.maps.MapTypeId.ROADMAP
//     }
//     var map = new google.maps.Map(document.getElementById("map"), myOptions);
// //     var marker = new google.maps.Marker({
// //        position: new google.maps.LatLng(22.810929,113.224045),
// //        title:"Marker1"
// //    });
// //    marker.setMap(map); 
    
//     var input = document.getElementById('pac-input');
//     var button = document.getElementById('button');
// //    map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);
// //    map.controls[google.maps.ControlPosition.TOP_LEFT].push(button);
//   }
 
//   function loadScript() {
//     var script = document.createElement("script");
//     script.type = "text/javascript";
//     script.src = "http://maps.googleapis.com/maps/api/js?key=AIzaSyD3g40E3xMy3PhXoZbIRFz9FEx_w7vcOrA&callback=initialize";
//     document.body.appendChild(script);
//   }
//   window.onload = loadScript;
//   //// End Google Maps ////